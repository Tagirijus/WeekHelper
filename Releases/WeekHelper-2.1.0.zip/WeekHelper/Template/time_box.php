<div class="weekhelper-time-box-container">
    <span id="currentDateTimeBox">
    </span>
</div>