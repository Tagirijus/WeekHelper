<?php

$times = $tagiTimes($project['id']);
$captions = $this->hoursViewHelper->getLevelCaptions();

require(__DIR__ . '/../hours_header.php');
