<br>
<i style="opacity: 0.5; display: inline-block; margin-top: 0.5em;">
    <?= t('1 complexity stands for') . ' ' . $non_time_mode_minutes . ' ' . t('minutes') ?>
</i>