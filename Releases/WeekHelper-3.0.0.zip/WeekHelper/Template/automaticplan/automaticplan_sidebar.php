<li <?= $this->app->checkMenuSelection('AddShortcutsController', 'getAutomaticPlan') ?>>
    <a href="/weekhelper/automaticplan">Automatic Plan</a>
</li>
