<?php

return array(
    'Add little helper for better plan the week ahead' => 'Ein kleiner Helfer, um die Woche besser voraus planen zu können',
    'WeekHelper configuration' => 'WeekHelper Einstellungen',
    'Date in the header' => 'Datum im Header',
    'Week insert pattern [triggered on "w" in task title input]' => 'Wochen-Einfüg-Pattern [wird im Task-Titel durch die Eingabe von "w" ausgelöst]',
    'Options are: {YEAR_SHORT}=two digit year, {YEAR}=four digit year, {WEEK}=week number' => 'Optionen sind: {YEAR_SHORT}=Jahr mit zwei Ziffern, {YEAR}=Jahr mit vier Ziffern, {WEEK}=Wochennummer',
    'Change a tasks title where the week-pattern, if it exists, will be added one week' => 'Ändere den Task-Titel gemäß des Wochen-Einfüg-Patterns, falls es existiert, und addiere eine Woche'
);
