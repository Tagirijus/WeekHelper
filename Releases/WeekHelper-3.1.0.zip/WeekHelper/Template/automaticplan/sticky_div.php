<div class="plan-sticky-container">
    <?= $this->render('WeekHelper:automaticplan/automaticplan', [
        'planner' => $planner
    ]) ?>
</div>