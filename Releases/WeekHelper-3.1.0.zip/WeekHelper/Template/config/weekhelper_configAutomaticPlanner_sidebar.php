<li <?= $this->app->checkMenuSelection('WeekHelperController', 'showConfigAutomaticPlanner') ?>>
    <a href="/weekhelper/configAutomaticPlanner"><?= t('WeekHelper automatic planner configuration') ?></a>
</li>
