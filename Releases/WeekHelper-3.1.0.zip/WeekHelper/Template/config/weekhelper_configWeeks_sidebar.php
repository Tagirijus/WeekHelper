<li <?= $this->app->checkMenuSelection('WeekHelperController', 'showConfigWeeks') ?>>
    <a href="/weekhelper/configWeeks"><?= t('WeekHelper weeks configuration') ?></a>
</li>
