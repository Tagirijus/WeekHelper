<li <?= $this->app->checkMenuSelection('WeekHelperController', 'showConfigTimetagger') ?>>
    <a href="/weekhelper/configTimetagger"><?= t('WeekHelper Timetagger configuration') ?></a>
</li>
