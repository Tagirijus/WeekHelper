<?php

namespace Kanboard\Plugin\WeekHelper\Service;

use Kanboard\Core\Base;
use Kanboard\Plugin\WeekHelper\Helper\TimeHelper;
use Kanboard\Plugin\WeekHelper\Model\DistributionLogic;
use Kanboard\Plugin\WeekHelper\Model\TasksPlan;
use Kanboard\Plugin\WeekHelper\Model\CalDAVFetcher;
use Kanboard\Plugin\WeekHelper\Model\CalDAVConverter;
use Kanboard\Plugin\WeekHelper\Model\TimePoint;

class AutomaticPlanner extends Base
{
    /**
     * The level, which stands for the active week.
     *
     * @var string
     **/
    var $level_active_week = '';

    /**
     * All active projects, parsed with their additional meta data.
     *
     * @var array
     **/
    var $projects = null;

    /**
     * The raw config for the sorting logic. It's a cache variable
     * so that for getting this config no DB query has to be done
     * everytime.
     *
     * @var string
     **/
    var $sorting_logic_config = null;

    /**
     * The raw config for the time slots / distribution logic.
     * It is an array with the weekdays (short) as key and the
     * raw config string from the user.
     *
     * @var array
     **/
    var $distribution_config = null;

    /**
     * The cache variable for the tasks of the active week.
     *
     * @var array
     **/
    var $tasks_active_week = null;

    /**
     * The cache variable for the tasks of the planned week.
     *
     * @var array
     **/
    var $tasks_planned_week = null;

    /**
     * The TasksPlan instance for the active week.
     *
     * @var TasksPlan
     **/
    var $tasks_plan_active_week = null;

    /**
     * The TasksPlan instance for the planned week.
     *
     * @var TasksPlan
     **/
    var $tasks_plan_planned_week = null;

    /**
     * The pseudo tasks array from the DistributionLogic
     * instance. Needed internally for also getting
     * the blocking pseudo tasks as a tasks like they
     * were planned tasks.
     *
     *  [
     *      'active' => ...,
     *      'planned' => ...
     *  ]
     *
     * @var array
     **/
    var $blocking_pseudo_tasks = null;

    /**
     * Get (and if needed first initialize it) the internal sorting
     * logic config array.
     *
     * @return array
     */
    public function getSortingLogicConfig()
    {
        if (is_null($this->sorting_logic_config)) {
            $this->initSortingLogicConfig();
        }
        return $this->sorting_logic_config;
    }

    /**
     * Initialize the sorting logic config and store it in the
     * internal attribute for this value.
     */
    private function initSortingLogicConfig()
    {
        $this->sorting_logic_config = $this->configModel->get('weekhelper_sorting_logic', '');
    }

    /**
     * Get (and if needed first initialize it) the internal distribution
     * config array.
     *
     * @return array
     */
    public function getDistributionConfig()
    {
        if (is_null($this->distribution_config)) {
            $this->initDistributionConfig();
        }
        return $this->distribution_config;
    }

    /**
     * Initialize the distribution config and store it in the
     * internal attribute for this value.
     */
    private function initDistributionConfig()
    {
        $this->distribution_config = [
            'mon' => $this->configModel->get('weekhelper_monday_slots', ''),
            'tue' => $this->configModel->get('weekhelper_tuesday_slots', ''),
            'wed' => $this->configModel->get('weekhelper_wednesday_slots', ''),
            'thu' => $this->configModel->get('weekhelper_thursday_slots', ''),
            'fri' => $this->configModel->get('weekhelper_friday_slots', ''),
            'sat' => $this->configModel->get('weekhelper_saturday_slots', ''),
            'sun' => $this->configModel->get('weekhelper_sunday_slots', ''),
            'min_slot_length' => $this->configModel->get('weekhelper_minimum_slot_length', 0),
            'non_time_mode_minutes' => $this->configModel->get('hoursview_non_time_mode_minutes', 0),
        ];
    }

    /**
     * Get (and if needed first initialize it) the internal array
     * for the tasks of the active week.
     *
     * @return array
     */
    public function getTasksActiveWeek()
    {
        if (is_null($this->tasks_active_week)) {
            $this->initTasksActiveWeek();
        }
        return $this->tasks_active_week;
    }

    /**
     * Initialize the tasks of the active week. Also attach the
     * projects metadata to each task for easier access later on.
     */
    private function initTasksActiveWeek()
    {
        $this->helper->hoursViewHelper->initTasks();
        $this->level_active_week = $this->configModel->get('weekhelper_level_active_week', '');
        $this->tasks_active_week = $this->helper->hoursViewHelper
            ->getTimes()->getTasksByLevel($this->level_active_week);
    }

    /**
     * Get (and if needed first initialize it) the internal array
     * for the tasks of the planned week.
     *
     * @return array
     */
    public function getTasksPlannedWeek()
    {
        if (is_null($this->tasks_planned_week)) {
            $this->initTasksPlannedWeek();
        }
        return $this->tasks_planned_week;
    }

    /**
     * Initialize the tasks of the active week. Also attach the
     * projects metadata to each task for easier access later on.
     */
    private function initTasksPlannedWeek()
    {
        $this->helper->hoursViewHelper->initTasks();
        $level_planned_week = $this->configModel->get('weekhelper_level_planned_week', '');
        $this->tasks_planned_week = $this->helper->hoursViewHelper
            ->getTimes()->getTasksByLevel($level_planned_week);
    }

    /**
     * This is the most important output. This method basically will get
     * all other "getAutomaticPlan..." methods their base to work with.
     * It is an array, which holds the week plan and further data.
     *
     * The array structure is:
     *     [
     *         'active' => [
     *             'mon' => [array with sorted tasks],
     *             'tue' => [array with sorted tasks],
     *             ...
     *             'sun' => [array with sorted tasks],
     *             'overflow' => [array with sorted tasks]
     *         ],
     *         'planned' => [
     *             'mon' => [array with sorted tasks],
     *             'tue' => [array with sorted tasks],
     *             ...
     *             'sun' => [array with sorted tasks],
     *             'overflow' => [array with sorted tasks]
     *         ],
     *         maybe more data here later ...
     *     ]
     *
     * @param  boolean $add_blocking
     * @return array
     */
    public function getAutomaticPlanAsArray($add_blocking = false)
    {
        // prepare plans
        $active_plan = $this->getTasksPlan('active')->getPlan();
        $planned_plan = $this->getTasksPlan('planned')->getPlan();
        if ($add_blocking) {
            $active_plan = TasksPlan::combinePlans(
                $active_plan,
                $this->blocking_pseudo_tasks['active']
            );
            $planned_plan = TasksPlan::combinePlans(
                $planned_plan,
                $this->blocking_pseudo_tasks['planned']
            );
        }
        return [
            'active' => $active_plan,
            'planned' => $planned_plan,
        ];
    }

    /**
     * Instantiate the internal TasksPlan instances.
     */
    public function initTasksPlans()
    {
        [
            $this->tasks_plan_active_week,
            $this->blocking_pseudo_tasks['active']
        ] = $this->prepareWeek(
            $this->getTasksActiveWeek(),
            false,
            $this->configModel->get('weekhelper_block_active_week', '')
        );
        [
            $this->tasks_plan_planned_week,
            $this->blocking_pseudo_tasks['planned']
        ] = $this->prepareWeek(
            $this->getTasksPlannedWeek(),
            true,
            $this->configModel->get('weekhelper_block_planned_week', '')
        );
    }

    /**
     * Return the internal tasks plan for the week:
     * "active" or "planned". It will also first
     * initialize the internal variables, if needed.
     *
     * @param string  $week
     * @return TasksPlan
     */
    public function getTasksPlan($week = 'active')
    {
        // check if null; both will be initialized then
        if (is_null($this->tasks_plan_active_week)) {
            $this->initTasksPlans();
        }
        if ($week == 'active') {
            return $this->tasks_plan_active_week;
        } else {
            return $this->tasks_plan_planned_week;
        }
    }

    /**
     * Prepare an active week with the given tasks
     * and return its TasksPlan instance and the
     * blocking pseudo tasks as an array like:
     *     [
     *         TasksPlan,
     *         blocking_pseudo_tasks
     *     ]
     *
     * @param  array $tasks
     * @param  boolean $ignore_now
     * @param  string $blocking_config
     * @return array
     */
    public function prepareWeek(
        $tasks,
        $ignore_now = false,
        $blocking_config = ''
    )
    {
        $distributor = new DistributionLogic($this->getDistributionConfig());
        if (!$ignore_now) {
            $distributor->depleteUntilNow();
            $distributor->depleteByTimeSpansConfigUntilNow($blocking_config);
            $distributor->depleteProjectQuota(
                $this->helper->hoursViewHelper->getTimes(),
                $this->level_active_week,
                new TimePoint()
            );
        } else {
            $distributor->depleteByTimeSpansConfig($blocking_config);
        }
        $distributor->distributeTasks($tasks);
        $tasks_plan = $distributor->getTasksPlan();

        return [$tasks_plan, $distributor->getBlockingPseudoTasks()];
    }

    /**
     * Get the automatic plan as plaintext.
     *
     * The $params parameter can hold the following
     * options, which would be basically parameters
     * themself. But for better extending I made this
     * one an array:
     *
     *     week_only:
     *         - '': both weeks
     *         - 'active': only active week
     *         - 'planned': only planned / next week
     *
     *     days:
     *         A string containing the abbreviation
     *         weekdays which should be shown. Can
     *         be comma separated. String will just
     *         be checked with "str_contains()" later.
     *         BUT: it can also contain numbers, which
     *         stand for the relation to "today". So it
     *         can contain "0" and stand for "today". Or
     *         "-1" which stand for "yesterday". This way
     *         it should be possible to define days
     *         dynamically.
     *
     *     hide_times:
     *         If true the day times will be hidden.
     *
     *     hide_length:
     *         If true the task length will be hidden.
     *
     *     hide_task_title:
     *         If true, it hides the original task title.
     *
     *     prepend_project_name:
     *         If true, it prepends the project name.
     *
     *     prepend_project_alias:
     *         If true, it prepend the project alias.
     *
     *     show_day_planned:
     *         If true, show the times for a whole day.
     *
     *     show_week_times:
     *         If true, shows time stats for the week.
     *
     *     add_blocking:
     *         If true, blocking timespans will be shown
     *         as planned tasks as well.
     *
     * @param  array $params See docstring for info
     * @return string
     */
    public function getAutomaticPlanAsText($params = [])
    {
        // params preparation
        $week_only = $params['week_only'] ?? '';
        $show_week_times = $params['show_week_times'] ?? false;

        if ($week_only == 'active' || $week_only == '') {
            // both weeks are needed, thus also a title for
            // each week to distinguish both
            if ($week_only == '') {
                $out = "ACTIVE WEEK\n";
                if ($show_week_times) {
                    $out .= $this->prepareWeekTimesString('active') . "\n";
                }
                $out .= "\n";
            } elseif ($show_week_times) {
                $out = $this->prepareWeekTimesString('active') . "\n\n";
            }
            $this->formatSinglePlaintextDays(
                $out,
                'active',
                $params
            );
        }

        if ($week_only == 'planned' || $week_only == '') {
            // both weeks are needed, thus also a title for
            // each week to distinguish both
            if ($week_only == '') {
                $out .= "\n\n";
                $out .= "PLANNED WEEK\n";
                if ($show_week_times) {
                    $out .= $this->prepareWeekTimesString('planned') . "\n";
                }
                $out .= "\n";
            } elseif ($show_week_times) {
                $out = $this->prepareWeekTimesString('planned') . "\n\n";
            }
            $this->formatSinglePlaintextDays(
                $out,
                'planned',
                $params
            );
        }

        return $out;
    }

    /**
     * Prepare the week times string for the given week,
     * which is "active" or "planned".
     *
     * @param  string $week
     * @return string
     */
    public function prepareWeekTimesString($week = 'active')
    {
        $planned = $this->getTasksPlan($week)->getGlobalTimesForWeek()['planned'];
        $spent = $this->getTasksPlan($week)->getGlobalTimesForWeek()['spent'];
        $overflow = $this->getTasksPlan($week)->getGlobalTimesForOverflow()['planned'];
        $available = $this->getTasksPlan($week)->getAvailableSlotTime('all');

        $out = 'Planned: ' . TimeHelper::minutesToReadable($planned, ' h');
        $out .= ', Spent: ' . TimeHelper::minutesToReadable($spent, ' h');
        $out .= ', Free: ' . TimeHelper::minutesToReadable($available, ' h');
        $out .= "\n";

        if ($overflow > 0) {
            $out .= '⚠ Overflow: ' . TimeHelper::minutesToReadable($overflow, ' h');
            $out .= "\n";
        }

        return $out;
    }

    /**
     * Extend the $out string with the given planned week,
     * which is either the active one or the planned one.
     *
     * @param  string &$out
     * @param  string $week
     * @param  array $params See getAutomaticPlanAsText() for info
     */
    public function formatSinglePlaintextDays(
        &$out,
        $week,
        $params = []
    )
    {
        // with this variable I can have better visual breakpoints so that it
        // is more clear where whole work blocks are being separated
        $last_time = 0;

        // params preparation
        $days = $params['days'] ?? 'mon,tue,wed,thu,fri,sat,sun,overflow,ovr';
        $add_blocking = $params['add_blocking'] ?? false;

        // prepare the plan to show
        if ($add_blocking) {
            $plan = TasksPlan::combinePlans(
                $this->getTasksPlan($week)->getPlan(),
                $this->blocking_pseudo_tasks[$week]
            );
        } else {
            $plan = $this->getTasksPlan($week)->getPlan();
        }

        foreach ($plan as $day => $tasks) {
            if (
                str_contains($days, $day)
                || (
                    str_contains($days, 'ovr')
                    && $day == 'overflow'
                )
                ||
                str_contains($days, TimeHelper::diffOfWeekDays('', $day))
            ) {
                // prepare the day times string
                $day_times = $params['show_day_planned'] ?? false;
                if ($day_times) {
                    $day_times = (
                        TimeHelper::minutesToReadable(
                            $this->getTasksPlan($week)->getGlobalTimesForDay($day)['planned'],
                            'h'
                        ) . (
                            $day != 'overflow' ?
                            (
                                ' | ' .
                                TimeHelper::minutesToReadable(
                                    $this->getTasksPlan($week)->getAvailableSlotTime($day),
                                    'h'
                                )
                            ) : ''
                        )
                    );
                } else {
                    $day_times = '';
                }

                // print out day name, if there are probably more
                // than one day wanted
                if (str_contains($days, ',')) {
                    $out .= "               ";
                    $out .= strtoupper($day) . ($day_times ? " ($day_times)" : '') . "\n";

                // probably just one day; then maybe at least
                // print out the day time stats if wanted
                } else {
                    $out .= ($day_times ? "$day_times:\n" : '');
                }

                foreach ($tasks as $task) {
                    if ($last_time == 0) {
                        $last_time = $task['end'];
                    } else {
                        if ($task['start'] - $last_time > 1) {
                            $out .= "\n";
                        }
                        $last_time = $task['end'];
                    }
                    $out .= $this->formatSinglePlaintextTask(
                        $task,
                        $params
                    );
                }
                $out .= "\n\n";
            }
        }
    }

    /**
     * Format teh given task into a predefined line, which shall
     * represent a single task.
     *
     * Maybe one day it might even be configurable via the settings.
     *
     * @param  array $task
     * @param  array $params See getAutomaticPlanAsText() for info
     * @return string
     */
    public function formatSinglePlaintextTask($task, $params = [])
    {
        $out = '';
        $start_daytime = TimeHelper::minutesToReadable($task['start']);
        $end_daytime = TimeHelper::minutesToReadable($task['end']);
        $length = TimeHelper::minutesToReadable($task['length'], ' h');

        // time of day
        if (!($params['hide_times'] ?? false)) {
            $out .= (
                str_pad($start_daytime, 5, " ", STR_PAD_LEFT)
                . ' - '
                . str_pad($end_daytime, 5, " ", STR_PAD_LEFT)
            );
            $out .= '  ';
        }

        // task title
        $out .= $this->formatSinglePlaintextTitle($task, $params);

        // length of task
        if (!($params['hide_length'] ?? false)) {
            $out .= " (" . $length . ")";
        }

        // has overtime icon
        $overtime = $task['task']['time_overtime'] ?? 0.0;
        $out = $overtime > 0.0 ? $out . '⚠️' : $out;

        $out .= "\n";

        return $out;
    }

    /**
     * Format a single plaintext title.
     *
     * TODO:
     * Later I might consider making this whole formatting
     * logic to set via the config by the user. Maybe with
     * some tiny templater language.
     * On the other site this way it is choosable what to
     * show from the URI ... this is also good and flexible.
     * I will see!
     *
     * @param  array $task
     * @param  array $params See getAutomaticPlanAsText() for info
     * @return string
     */
    public function formatSinglePlaintextTitle($task, $params = [])
    {
        $title = $params['hide_task_title'] ?? false ? '' : $task['task']['title'];

        $title = (
            $params['prepend_project_name'] ?? false ?
            $task['task']['project_name'] . ': ' . $title
            : $title
        );

        $title = (
            $params['prepend_project_alias'] ?? false ?
            (
                $task['task']['project_alias'] != '' ?
                '[' . $task['task']['project_alias'] . '] ' . $title
                : $title
            )
            : $title
        );

        $title = (
            $task['task']['is_blocking'] ?? false ?
            '~~  ' . $title
            : $title
        );

        // is running icon
        $title = isset($task['task']['is_running']) ? '🔴 ' . $title : $title;

        return $title;
    }

    /**
     * This function will update the blocking tasks / timeslots
     * from the CalDAV calendar/s from the config.
     *
     * Output is True on success or string message on fail.
     *
     * @return boolean
     */
    public function updateBlockingTasks()
    {
        try {
            $caldav_fetcher = new CalDAVFetcher(
                $this->configModel->get('weekhelper_caldav_user', ''),
                $this->configModel->get('weekhelper_caldav_app_pwd', '')
            );
            $urls = trim($this->configModel->get('weekhelper_calendar_urls', ''));

            $caldav_converter = new CalDAVConverter($caldav_fetcher, $urls);

            $blocking_active = $caldav_converter->generateBlockingStringForActiveWeek();
            $blocking_planned = $caldav_converter->generateBlockingStringForPlannedWeek();

            $values = [
                'weekhelper_block_active_week' => $blocking_active,
                'weekhelper_block_planned_week' => $blocking_planned,
            ];

            if ($this->configModel->save($values)) {
                return true;
            } else {
                $this->logger->info(json_encode('WeekHelper blocking config could not be saved.'));
                return false;
            }
        } catch (\Exception $e) {
            $this->logger->info(json_encode($e));
            return false;
        }

    }
}
