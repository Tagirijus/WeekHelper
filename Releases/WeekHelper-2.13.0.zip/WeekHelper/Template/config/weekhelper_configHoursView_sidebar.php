<li <?= $this->app->checkMenuSelection('WeekHelperController', 'showConfigHoursView') ?>>
    <a href="/weekhelper/configHoursView"><?= t('WeekHelper hours view configuration') ?></a>
</li>
