<li <?= $this->app->checkMenuSelection('WeekHelperController', 'show') ?>>
    <a href="/weekhelper/config"><?= t('WeekHelper configuration') ?></a>
</li>
