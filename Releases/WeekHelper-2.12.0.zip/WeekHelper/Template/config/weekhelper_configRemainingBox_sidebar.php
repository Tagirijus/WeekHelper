<li <?= $this->app->checkMenuSelection('WeekHelperController', 'showConfigRemainingBox') ?>>
    <a href="/weekhelper/configRemainingBox"><?= t('WeekHelper remaining box configuration') ?></a>
</li>
